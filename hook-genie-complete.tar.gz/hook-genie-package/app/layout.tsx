import "./globals.css";
import { MacalySandboxBridge } from '../.sandbox/sandbox-bridge';
import type { Metadata } from "next";
import { Inter } from "next/font/google";
import { Toaster } from "@/components/ui/sonner";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Hook Genie - AI Viral Content Generator",
  description: "Generate viral social media hooks, captions, and hashtags with AI. Create TikTok scripts, YouTube titles, and boost your content engagement.",
  keywords: "viral content, social media, AI generator, hooks, captions, hashtags, TikTok, YouTube, content creator",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <MacalySandboxBridge><body className={inter.className}>
        {children}
        <Toaster 
          position="top-right"
          theme="dark"
          richColors
          closeButton
        />
      </body></MacalySandboxBridge>
    </html>
  );
}