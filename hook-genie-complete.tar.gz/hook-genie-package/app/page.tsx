'use client';

import { useState } from 'react';
import { ContentGenerator } from '@/components/ContentGenerator';
import { Sidebar } from '@/components/Sidebar';
import { PricingCard } from '@/components/PricingCard';
import { CalendarPlanner } from '@/components/CalendarPlanner';
import { CreditCounter } from '@/components/CreditCounter';
import { Menu } from 'lucide-react';

export type NavigationSection = 'generator' | 'pricing' | 'calendar' | 'history';

export default function Home() {
  const [activeSection, setActiveSection] = useState<NavigationSection>('generator');
  const [credits, setCredits] = useState(25); // Starting with 25 free credits
  const [sidebarOpen, setSidebarOpen] = useState(false);

  console.log('Home component rendered, activeSection:', activeSection, 'credits:', credits, 'sidebarOpen:', sidebarOpen);

  const renderContent = () => {
    console.log('Rendering content for section:', activeSection);
    
    switch (activeSection) {
      case 'generator':
        return <ContentGenerator credits={credits} setCredits={setCredits} />;
      case 'pricing':
        return <PricingCard />;
      case 'calendar':
        return <CalendarPlanner />;
      case 'history':
        return (
          <div className="content-card">
            <h2 className="text-2xl font-bold gradient-text mb-4">Generation History</h2>
            <p className="text-muted-foreground">Your past generated content will appear here.</p>
          </div>
        );
      default:
        return <ContentGenerator credits={credits} setCredits={setCredits} />;
    }
  };

  return (
    <div className="min-h-screen lg:flex bg-dark-gradient">
      <Sidebar 
        activeSection={activeSection} 
        setActiveSection={setActiveSection}
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />
      
      <main className="flex-1 lg:ml-0 p-4 lg:p-8 overflow-auto">
        <div className="max-w-6xl mx-auto">
          <header className="mb-6 lg:mb-8">
            <div className="flex items-center justify-between mb-4 lg:mb-0">
              {/* Mobile Menu Button */}
              <button
                onClick={() => setSidebarOpen(true)}
                className="lg:hidden p-2 rounded-lg bg-white/10 border border-white/20 hover:bg-white/20 transition-colors"
              >
                <Menu className="w-6 h-6" />
              </button>
              
              <div className="flex-1 lg:flex-none">
                <h1 className="text-2xl lg:text-4xl font-bold gradient-text text-shadow mb-1 lg:mb-2">
                  Hook Genie ✨
                </h1>
                <p className="text-sm lg:text-xl text-muted-foreground">
                  AI-powered viral content generator for creators
                </p>
              </div>
              
              <CreditCounter credits={credits} />
            </div>
          </header>
          
          {renderContent()}
        </div>
      </main>
    </div>
  );
}