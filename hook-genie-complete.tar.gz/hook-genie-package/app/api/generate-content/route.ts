import { generateText } from 'ai';
import { openai } from '@ai-sdk/openai';

export async function POST(req: Request) {
  let requestData: any = {};
  
  try {
    console.log('Content generation API called');
    
    requestData = await req.json();
    const { contentType, topic, niche, tone, additionalContext } = requestData;
    
    console.log('Request data:', {
      contentType,
      topic: topic.substring(0, 100),
      niche,
      tone,
      additionalContext: additionalContext?.substring(0, 100)
    });

    let systemPrompt = '';
    let userPrompt = '';
    
    switch (contentType) {
      case 'hooks':
        systemPrompt = `You are a viral content specialist who creates highly engaging social media hooks. Your hooks consistently generate millions of views and high engagement rates. Focus on psychological triggers, curiosity gaps, and emotional resonance.`;
        
        userPrompt = `Create 5 viral social media hooks for the following content:
        
Topic: ${topic}
Niche: ${niche}
Tone: ${tone}
${additionalContext ? `Additional Context: ${additionalContext}` : ''}

Requirements:
- Each hook should be 1-2 sentences maximum
- Use psychological triggers (curiosity, fear of missing out, controversy, etc.)
- Include emotional language and power words
- Make them scroll-stopping and share-worthy
- Ensure they match the specified tone
- Add relevant emojis strategically

Return a JSON object with this structure:
{
  "hooks": ["hook1", "hook2", "hook3", "hook4", "hook5"],
  "emojis": ["🔥", "💡", "✨", "🚀", "💯"],
  "metrics": {
    "estimatedReach": "500K+",
    "engagementBoost": "+180%",
    "viralPotential": "High"
  }
}`;
        break;

      case 'youtube-titles':
        systemPrompt = `You are a YouTube optimization expert who creates click-worthy titles that drive massive views. Your titles consistently achieve high CTR and viewer retention.`;
        
        userPrompt = `Create 5 compelling YouTube video titles for:
        
Topic: ${topic}
Niche: ${niche}
Tone: ${tone}
${additionalContext ? `Additional Context: ${additionalContext}` : ''}

Requirements:
- 60 characters or less for optimal display
- Include power words and numbers when relevant
- Create curiosity gaps and emotional hooks
- Use proven YouTube title formulas
- Make them click-worthy but not clickbait
- Match the specified tone

Return a JSON object with this structure:
{
  "youtubeTitle": ["title1", "title2", "title3", "title4", "title5"],
  "emojis": ["🎯", "🔥", "💡", "⚡", "🚀"],
  "metrics": {
    "estimatedReach": "1M+",
    "engagementBoost": "+220%",
    "viralPotential": "Very High"
  }
}`;
        break;

      case 'tiktok-scripts':
        systemPrompt = `You are a TikTok content creator who consistently creates viral videos. You understand the platform's algorithm, trending formats, and what makes content shareable.`;
        
        userPrompt = `Create a complete TikTok video script for:
        
Topic: ${topic}
Niche: ${niche}
Tone: ${tone}
${additionalContext ? `Additional Context: ${additionalContext}` : ''}

Requirements:
- Hook: Strong opening line (first 3 seconds)
- Content: 4-6 main points or steps
- CTA: Clear call-to-action for engagement
- Keep it conversational and authentic
- Include trending elements when appropriate
- Optimize for 15-30 second videos

Return a JSON object with this structure:
{
  "tiktokScript": {
    "hook": "Compelling opening line",
    "content": ["point1", "point2", "point3", "point4"],
    "cta": "Strong call-to-action"
  },
  "emojis": ["🎬", "🔥", "💡", "✨", "🚀"],
  "metrics": {
    "estimatedReach": "2M+",
    "engagementBoost": "+300%",
    "viralPotential": "Extremely High"
  }
}`;
        break;

      case 'hashtags':
        systemPrompt = `You are a social media strategist specializing in hashtag research and optimization. You understand trending hashtags, niche communities, and engagement patterns across platforms.`;
        
        userPrompt = `Create strategic hashtag sets for:
        
Topic: ${topic}
Niche: ${niche}
Tone: ${tone}
${additionalContext ? `Additional Context: ${additionalContext}` : ''}

Requirements:
- Trending: 5 currently trending hashtags
- Niche: 5 niche-specific hashtags for targeted reach
- Engagement: 5 hashtags known for high engagement
- Mix of high, medium, and low competition tags
- Relevant to the topic and niche
- No hashtag should exceed 20 characters

Return a JSON object with this structure:
{
  "hashtags": {
    "trending": ["#hashtag1", "#hashtag2", "#hashtag3", "#hashtag4", "#hashtag5"],
    "niche": ["#hashtag1", "#hashtag2", "#hashtag3", "#hashtag4", "#hashtag5"],
    "engagement": ["#hashtag1", "#hashtag2", "#hashtag3", "#hashtag4", "#hashtag5"]
  },
  "emojis": ["🏷️", "🔥", "🎯", "💡", "📈"],
  "metrics": {
    "estimatedReach": "750K+",
    "engagementBoost": "+150%",
    "viralPotential": "High"
  }
}`;
        break;

      default:
        throw new Error('Invalid content type');
    }

    console.log('Generating content with AI...');
    
    const { text } = await generateText({
      model: openai('gpt-4o'),
      system: systemPrompt,
      prompt: userPrompt,
      temperature: 0.8,
      maxTokens: 1500,
    });

    console.log('AI response received, length:', text.length);
    
    // Parse the JSON response
    let parsedContent;
    try {
      // Extract JSON from response if it's wrapped in markdown
      const jsonMatch = text.match(/```json\n([\s\S]*?)\n```/) || text.match(/\{[\s\S]*\}/);
      const jsonStr = jsonMatch ? (jsonMatch[1] || jsonMatch[0]) : text;
      parsedContent = JSON.parse(jsonStr);
      console.log('Successfully parsed AI response');
    } catch (parseError) {
      console.error('Failed to parse AI response as JSON:', parseError);
      // Fallback response
      parsedContent = {
        hooks: [text],
        emojis: ['🔥', '💡', '✨'],
        metrics: {
          estimatedReach: '500K+',
          engagementBoost: '+150%',
          viralPotential: 'High'
        }
      };
    }

    console.log('Returning generated content');
    return new Response(JSON.stringify(parsedContent), {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
      },
    });

  } catch (error) {
    console.error('Content generation error:', error);
    
    // Fallback to mock data for demo purposes
    const fallbackContentType = requestData.contentType || 'hooks';
    console.log('Using fallback mock data for content type:', fallbackContentType);
    
    let mockContent;
    
    switch (fallbackContentType) {
      case 'hooks':
        mockContent = {
          hooks: [
            `🌅 The 3-minute morning routine that changed my skin FOREVER (you won't believe #3!)`,
            `POV: You wake up with glass skin because you finally found THE routine 💎`,
            `Stop scrolling if you want skin that literally GLOWS from within ✨`,
            `The skincare secret Korean women don't want you to know (it's not what you think!)`,
            `I tried this viral skincare hack for 30 days and... *shows before/after* 🤯`
          ],
          emojis: ['🌅', '✨', '💎', '🤯', '🔥'],
          metrics: {
            estimatedReach: '750K+',
            engagementBoost: '+195%',
            viralPotential: 'Very High'
          }
        };
        break;
        
      case 'youtube-titles':
        mockContent = {
          youtubeTitle: [
            'I Tried The Viral Korean Glass Skin Routine For 30 Days',
            '5 Skincare Mistakes That Are AGING You (Stop Now!)',
            'Morning Routine That Gave Me Perfect Skin in 7 Days',
            'Dermatologist Reacts: TikTok Skincare Trends That Work',
            'The $5 Product That Replaced My Entire Skincare Routine'
          ],
          emojis: ['🎯', '🔥', '💡', '⚡', '🚀'],
          metrics: {
            estimatedReach: '1.2M+',
            engagementBoost: '+240%',
            viralPotential: 'Extremely High'
          }
        };
        break;
        
      case 'tiktok-scripts':
        mockContent = {
          tiktokScript: {
            hook: "POV: You finally found the morning routine that gives you glass skin",
            content: [
              "Start with a gentle cleanser - I use this $12 one from Target",
              "Apply vitamin C serum while skin is still damp",
              "Don't forget SPF! This one doesn't leave white cast",
              "The secret ingredient? Patience and consistency ✨"
            ],
            cta: "Follow for more skincare tips that actually work! 💫"
          },
          emojis: ['🎬', '🔥', '💡', '✨', '🚀'],
          metrics: {
            estimatedReach: '2.5M+',
            engagementBoost: '+320%',
            viralPotential: 'Viral Ready'
          }
        };
        break;
        
      case 'hashtags':
        mockContent = {
          hashtags: {
            trending: ['#skincare', '#glowup', '#morningroutine', '#glassskin', '#skincaretips'],
            niche: ['#koreanskcare', '#skincareaddict', '#healthyskin', '#skincarecommunity', '#beautytips'],
            engagement: ['#selfcare', '#confidence', '#skincareroutine', '#getready', '#skincarehacks']
          },
          emojis: ['🏷️', '🔥', '🎯', '💡', '📈'],
          metrics: {
            estimatedReach: '850K+',
            engagementBoost: '+175%',
            viralPotential: 'High'
          }
        };
        break;
        
      default:
        mockContent = {
          hooks: ['Check out this amazing content idea!'],
          emojis: ['🔥', '💡', '✨'],
          metrics: {
            estimatedReach: '500K+',
            engagementBoost: '+150%',
            viralPotential: 'High'
          }
        };
    }

    return new Response(JSON.stringify(mockContent), {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
      },
    });
  }
}