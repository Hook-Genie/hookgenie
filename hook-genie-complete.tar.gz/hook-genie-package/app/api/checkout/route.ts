import { NextRequest, NextResponse } from 'next/server';
import Stripe from 'stripe';

// Initialize Stripe with fallback for demo mode
const stripe = process.env.STRIPE_SECRET_KEY 
  ? new Stripe(process.env.STRIPE_SECRET_KEY)
  : null;

interface CheckoutRequestBody {
  planName: string;
  price: number;
  credits: number;
  isYearly: boolean;
}

export async function POST(request: NextRequest) {
  console.log('Stripe checkout API called');
  
  try {
    const body: CheckoutRequestBody = await request.json();
    console.log('Checkout request body:', body);
    
    const { planName, price, credits, isYearly } = body;
    
    // Demo mode fallback when no Stripe key is configured
    if (!stripe || !process.env.STRIPE_SECRET_KEY) {
      console.log('Demo mode: No Stripe key configured');
      return NextResponse.json({
        demoMode: true,
        message: 'Demo mode - Add STRIPE_SECRET_KEY environment variable for real payments',
        checkoutUrl: '/success?demo=true'
      });
    }
    
    // Create Stripe checkout session
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [
        {
          price_data: {
            currency: 'usd',
            product_data: {
              name: `Hook Genie ${planName}`,
              description: `${credits.toLocaleString()} AI content generations per month`,
              images: ['https://hookgenie.ai/logo.png'], // You can replace with actual logo
            },
            unit_amount: price * 100, // Stripe expects cents
            recurring: {
              interval: isYearly ? 'year' : 'month',
            },
          },
          quantity: 1,
        },
      ],
      mode: 'subscription',
      success_url: `${request.nextUrl.origin}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${request.nextUrl.origin}/cancel`,
      customer_creation: 'always',
      metadata: {
        planName,
        credits: credits.toString(),
        isYearly: isYearly.toString(),
      },
      subscription_data: {
        metadata: {
          planName,
          credits: credits.toString(),
        },
      },
    });

    console.log('Stripe checkout session created:', session.id);
    
    return NextResponse.json({
      checkoutUrl: session.url,
      sessionId: session.id
    });
    
  } catch (error) {
    console.error('Stripe checkout error:', error);
    
    return NextResponse.json(
      { 
        error: 'Failed to create checkout session',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}