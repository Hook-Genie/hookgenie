import { Suspense } from 'react';
import SuccessContent from './SuccessContent';

export default function SuccessPage() {
  console.log('Success page rendered');
  
  return (
    <Suspense 
      fallback={
        <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950 flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-500 mx-auto mb-4"></div>
            <p className="text-white">Loading success page...</p>
          </div>
        </div>
      }
    >
      <SuccessContent />
    </Suspense>
  );
}