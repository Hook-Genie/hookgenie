'use client';

import { useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, Home, Zap, Gift } from 'lucide-react';
import Link from 'next/link';

export default function SuccessContent() {
  const searchParams = useSearchParams();
  const sessionId = searchParams.get('session_id');
  const isDemoMode = searchParams.get('demo') === 'true';
  
  const [isLoading, setIsLoading] = useState(true);
  const [sessionData, setSessionData] = useState<any>(null);

  useEffect(() => {
    if (isDemoMode) {
      console.log('Demo mode success page');
      setIsLoading(false);
      return;
    }

    if (sessionId) {
      console.log('Fetching session data for:', sessionId);
      // In a real app, you'd fetch session details from your backend
      // For now, we'll simulate the response
      setTimeout(() => {
        setSessionData({
          planName: 'Creator Pro',
          credits: 500,
          amount: 29
        });
        setIsLoading(false);
      }, 1000);
    } else {
      setIsLoading(false);
    }
  }, [sessionId, isDemoMode]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-500 mx-auto mb-4"></div>
          <p className="text-white">Processing your subscription...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950 flex items-center justify-center p-4">
      <Card className="max-w-2xl w-full glass-morphism border-white/20">
        <CardHeader className="text-center pb-6">
          <div className="w-20 h-20 rounded-full bg-gradient-to-r from-green-400 to-emerald-500 mx-auto mb-6 flex items-center justify-center">
            <CheckCircle className="w-10 h-10 text-white" />
          </div>
          
          <CardTitle className="text-3xl font-bold gradient-text mb-2">
            {isDemoMode ? '🎉 Welcome to Hook Genie Demo!' : '🎉 Payment Successful!'}
          </CardTitle>
          
          <p className="text-xl text-muted-foreground">
            {isDemoMode 
              ? 'You\'re exploring Hook Genie in demo mode'
              : 'Your subscription is now active and ready to use'
            }
          </p>
        </CardHeader>

        <CardContent className="space-y-6">
          {isDemoMode ? (
            <div className="space-y-4">
              <Badge className="mx-auto flex w-fit bg-gradient-to-r from-orange-400 to-orange-600 text-white px-4 py-2">
                <Gift className="w-4 h-4 mr-2" />
                Demo Mode Active
              </Badge>
              
              <div className="p-6 rounded-xl bg-white/5 border border-white/10">
                <h3 className="text-lg font-semibold mb-3 text-white">✨ You can now explore:</h3>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-cyan-400" />
                    Generate viral hooks and captions
                  </li>
                  <li className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-cyan-400" />
                    Create TikTok and YouTube content
                  </li>
                  <li className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-cyan-400" />
                    Plan content with the calendar
                  </li>
                  <li className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-cyan-400" />
                    Try different tones and niches
                  </li>
                </ul>
              </div>
              
              <div className="text-center text-sm text-muted-foreground">
                <p>💡 Add your Stripe API keys to enable real payments</p>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {sessionData && (
                <div className="p-6 rounded-xl bg-white/5 border border-white/10">
                  <h3 className="text-lg font-semibold mb-3 text-white">📋 Subscription Details</h3>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-muted-foreground">Plan:</span>
                      <p className="font-medium text-white">{sessionData.planName}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Credits:</span>
                      <p className="font-medium text-cyan-400">{sessionData.credits.toLocaleString()}/month</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Amount:</span>
                      <p className="font-medium text-white">${sessionData.amount}/month</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Status:</span>
                      <p className="font-medium text-green-400">Active</p>
                    </div>
                  </div>
                </div>
              )}
              
              <div className="p-6 rounded-xl bg-white/5 border border-white/10">
                <h3 className="text-lg font-semibold mb-3 text-white">🚀 What's Next?</h3>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    Check your email for the receipt
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    Start generating viral content immediately
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    Manage your subscription in your account
                  </li>
                </ul>
              </div>
            </div>
          )}

          <div className="flex gap-4 pt-4">
            <Button asChild className="flex-1 bg-gradient-to-r from-purple-600 to-cyan-500 hover:from-purple-700 hover:to-cyan-600">
              <Link href="/">
                <Home className="w-4 h-4 mr-2" />
                Start Creating
              </Link>
            </Button>
            
            {!isDemoMode && (
              <Button variant="outline" asChild className="flex-1 border-white/20 hover:bg-white/10">
                <Link href="/account">
                  Manage Account
                </Link>
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}