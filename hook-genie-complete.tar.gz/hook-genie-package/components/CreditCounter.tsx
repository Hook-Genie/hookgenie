'use client';

import { Zap, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface CreditCounterProps {
  credits: number;
}

export function CreditCounter({ credits }: CreditCounterProps) {
  console.log('CreditCounter rendered with credits:', credits);

  const isLowCredits = credits <= 5;
  const isOutOfCredits = credits === 0;

  return (
    <div className="flex items-center gap-2 lg:gap-4">
      <div className="flex items-center gap-2 px-3 lg:px-4 py-2 rounded-xl glass-morphism border border-white/10">
        <Zap className={`w-4 h-4 ${isLowCredits ? 'text-hook-amber animate-pulse' : 'text-hook-cyan'}`} />
        <span className="font-semibold text-sm lg:text-base">
          {credits} {credits === 1 ? 'Credit' : 'Credits'}
        </span>
        {isLowCredits && !isOutOfCredits && (
          <span className="text-xs text-hook-amber font-medium animate-pulse hidden sm:inline">
            Running low!
          </span>
        )}
        {isOutOfCredits && (
          <span className="text-xs text-red-400 font-medium hidden sm:inline">
            No credits left
          </span>
        )}
      </div>
      
      {isLowCredits && (
        <Button 
          size="sm" 
          className="bg-gradient-to-r from-hook-purple to-hook-cyan hover:from-hook-purple/80 hover:to-hook-cyan/80 transition-all duration-300 hidden lg:flex"
        >
          <Plus className="w-4 h-4 mr-2" />
          Get More Credits
        </Button>
      )}
    </div>
  );
}