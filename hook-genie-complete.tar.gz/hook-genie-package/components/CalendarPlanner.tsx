'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar, Plus, TrendingUp, Video, Hash, Type, Clock, Target } from 'lucide-react';
import { toast } from 'sonner';

const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const contentTypes = {
  hooks: { icon: TrendingUp, color: 'text-hook-purple', bg: 'bg-hook-purple/20', label: 'Hook' },
  tiktok: { icon: Video, color: 'text-hook-cyan', bg: 'bg-hook-cyan/20', label: 'TikTok' },
  youtube: { icon: Type, color: 'text-hook-amber', bg: 'bg-hook-amber/20', label: 'YouTube' },
  hashtags: { icon: Hash, color: 'text-green-400', bg: 'bg-green-400/20', label: 'Hashtags' }
};

// Sample content calendar data
const sampleContent = [
  {
    id: 1,
    date: new Date(2025, 5, 30), // June 30, 2025
    type: 'hooks',
    title: 'Morning Skincare Routine',
    time: '9:00 AM',
    platform: 'Instagram',
    status: 'scheduled'
  },
  {
    id: 2,
    date: new Date(2025, 5, 30),
    type: 'tiktok',
    title: '5 Crypto Mistakes to Avoid',
    time: '6:00 PM',
    platform: 'TikTok',
    status: 'draft'
  },
  {
    id: 3,
    date: new Date(2025, 6, 1), // July 1, 2025
    type: 'youtube',
    title: 'AI Tools for Content Creators',
    time: '2:00 PM',
    platform: 'YouTube',
    status: 'published'
  },
  {
    id: 4,
    date: new Date(2025, 6, 2),
    type: 'hooks',
    title: 'Fitness Motivation Monday',
    time: '7:00 AM',
    platform: 'Instagram',
    status: 'scheduled'
  },
  {
    id: 5,
    date: new Date(2025, 6, 3),
    type: 'hashtags',
    title: 'Tech Startup Hashtag Strategy',
    time: '12:00 PM',
    platform: 'LinkedIn',
    status: 'draft'
  }
];

export function CalendarPlanner() {
  console.log('CalendarPlanner component rendered');
  
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);

  // Get the first day of the month and days in month
  const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
  const lastDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
  const daysInMonth = lastDayOfMonth.getDate();
  const startDay = firstDayOfMonth.getDay();

  // Create calendar days array
  const calendarDays: (number | null)[] = [];
  
  // Add empty cells for days before the first day of the month
  for (let i = 0; i < startDay; i++) {
    calendarDays.push(null);
  }
  
  // Add days of the month
  for (let day = 1; day <= daysInMonth; day++) {
    calendarDays.push(day);
  }

  const getContentForDate = (day: number) => {
    const date = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
    return sampleContent.filter(content => 
      content.date.toDateString() === date.toDateString()
    );
  };

  const handleDateClick = (day: number) => {
    const date = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
    setSelectedDate(date);
    console.log('Date selected:', date.toDateString());
  };

  const handleAddContent = () => {
    console.log('Add content clicked');
    toast.success('🎬 Opening content generator...', {
      description: 'Create new content for your calendar'
    });
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    const newDate = new Date(currentDate);
    if (direction === 'prev') {
      newDate.setMonth(currentDate.getMonth() - 1);
    } else {
      newDate.setMonth(currentDate.getMonth() + 1);
    }
    setCurrentDate(newDate);
    console.log('Navigate to month:', newDate.toLocaleDateString());
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'published': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'scheduled': return 'bg-hook-purple/20 text-hook-purple border-hook-purple/30';
      case 'draft': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  return (
    <div className="space-y-8">
      <Card className="content-card">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="gradient-text text-2xl flex items-center gap-2">
              <Calendar className="w-6 h-6" />
              Content Calendar
            </CardTitle>
            <Button 
              onClick={handleAddContent}
              className="bg-gradient-to-r from-hook-purple to-hook-cyan hover:from-hook-purple/80 hover:to-hook-cyan/80"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Content
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {/* Calendar Header */}
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-semibold">
                {currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
              </h3>
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => navigateMonth('prev')}
                  className="border-white/20 hover:bg-white/10"
                >
                  ←
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => navigateMonth('next')}
                  className="border-white/20 hover:bg-white/10"
                >
                  →
                </Button>
              </div>
            </div>

            {/* Days of week header */}
            <div className="grid grid-cols-7 gap-2">
              {daysOfWeek.map(day => (
                <div key={day} className="text-center text-sm font-medium text-muted-foreground p-2">
                  {day}
                </div>
              ))}
            </div>

            {/* Calendar Grid */}
            <div className="grid grid-cols-7 gap-2">
              {calendarDays.map((day, index) => {
                if (day === null) {
                  return <div key={index} className="p-2 h-24"></div>;
                }

                const dayContent = getContentForDate(day);
                const isToday = new Date().toDateString() === new Date(currentDate.getFullYear(), currentDate.getMonth(), day).toDateString();
                const isSelected = selectedDate?.toDateString() === new Date(currentDate.getFullYear(), currentDate.getMonth(), day).toDateString();

                return (
                  <div
                    key={day}
                    onClick={() => handleDateClick(day)}
                    className={`
                      p-2 h-24 border border-white/10 rounded-lg cursor-pointer transition-all duration-300 hover:bg-white/5
                      ${isToday ? 'ring-2 ring-hook-purple/50' : ''}
                      ${isSelected ? 'bg-hook-purple/20' : ''}
                    `}
                  >
                    <div className="text-sm font-medium mb-1">
                      {day}
                      {isToday && <span className="ml-1 text-xs text-hook-purple">Today</span>}
                    </div>
                    <div className="space-y-1">
                      {dayContent.slice(0, 2).map(content => {
                        const config = contentTypes[content.type as keyof typeof contentTypes];
                        const Icon = config.icon;
                        return (
                          <div 
                            key={content.id} 
                            className={`text-xs p-1 rounded ${config.bg} ${config.color} truncate`}
                          >
                            <Icon className="w-3 h-3 inline mr-1" />
                            {content.title}
                          </div>
                        );
                      })}
                      {dayContent.length > 2 && (
                        <div className="text-xs text-muted-foreground">
                          +{dayContent.length - 2} more
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Content Timeline */}
      <Card className="content-card">
        <CardHeader>
          <CardTitle className="text-xl gradient-text">Upcoming Content</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {sampleContent
              .filter(content => content.date >= new Date())
              .sort((a, b) => a.date.getTime() - b.date.getTime())
              .slice(0, 5)
              .map(content => {
                const config = contentTypes[content.type as keyof typeof contentTypes];
                const Icon = config.icon;
                
                return (
                  <div key={content.id} className="flex items-center gap-4 p-4 rounded-lg bg-white/5 border border-white/10">
                    <div className={`w-10 h-10 rounded-lg ${config.bg} flex items-center justify-center`}>
                      <Icon className={`w-5 h-5 ${config.color}`} />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium">{content.title}</h4>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {content.date.toLocaleDateString()} at {content.time}
                        </span>
                        <span className="flex items-center gap-1">
                          <Target className="w-3 h-3" />
                          {content.platform}
                        </span>
                      </div>
                    </div>
                    <Badge className={`${getStatusColor(content.status)} border`}>
                      {content.status}
                    </Badge>
                  </div>
                );
              })}
          </div>
        </CardContent>
      </Card>

      {/* Quick Stats */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card className="glass-morphism border border-white/10 p-4">
          <div className="text-center">
            <TrendingUp className="w-8 h-8 text-hook-purple mx-auto mb-2" />
            <p className="text-2xl font-bold">12</p>
            <p className="text-sm text-muted-foreground">This Month</p>
          </div>
        </Card>
        <Card className="glass-morphism border border-white/10 p-4">
          <div className="text-center">
            <Video className="w-8 h-8 text-hook-cyan mx-auto mb-2" />
            <p className="text-2xl font-bold">8</p>
            <p className="text-sm text-muted-foreground">TikTok Videos</p>
          </div>
        </Card>
        <Card className="glass-morphism border border-white/10 p-4">
          <div className="text-center">
            <Type className="w-8 h-8 text-hook-amber mx-auto mb-2" />
            <p className="text-2xl font-bold">5</p>
            <p className="text-sm text-muted-foreground">YouTube Titles</p>
          </div>
        </Card>
        <Card className="glass-morphism border border-white/10 p-4">
          <div className="text-center">
            <Hash className="w-8 h-8 text-green-400 mx-auto mb-2" />
            <p className="text-2xl font-bold">15</p>
            <p className="text-sm text-muted-foreground">Hashtag Sets</p>
          </div>
        </Card>
      </div>
    </div>
  );
}