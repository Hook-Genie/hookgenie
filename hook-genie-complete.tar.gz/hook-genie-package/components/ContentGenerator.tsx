'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { GeneratedContent } from '@/components/GeneratedContent';
import { Wand2, Loader2, TrendingUp, Video, Hash, Type } from 'lucide-react';
import { toast } from 'sonner';

interface ContentGeneratorProps {
  credits: number;
  setCredits: (credits: number) => void;
}

type ContentType = 'hooks' | 'youtube-titles' | 'tiktok-scripts' | 'hashtags';

const niches = [
  'Beauty & Skincare',
  'Fitness & Health',
  'Crypto & Finance',
  'Technology',
  'Lifestyle',
  'Food & Cooking',
  'Travel',
  'Business',
  'Education',
  'Entertainment'
];

const tones = [
  'Viral & Engaging',
  'Professional',
  'Casual & Fun',
  'Motivational',
  'Educational',
  'Controversial',
  'Emotional',
  'Humorous'
];

export function ContentGenerator({ credits, setCredits }: ContentGeneratorProps) {
  console.log('ContentGenerator rendered with credits:', credits);

  const [isGenerating, setIsGenerating] = useState(false);
  const [contentType, setContentType] = useState<ContentType>('hooks');
  const [topic, setTopic] = useState('');
  const [niche, setNiche] = useState('');
  const [tone, setTone] = useState('');
  const [additionalContext, setAdditionalContext] = useState('');
  const [generatedContent, setGeneratedContent] = useState<any>(null);

  const handleGenerate = async () => {
    console.log('Generate button clicked', {
      contentType,
      topic,
      niche,
      tone,
      additionalContext,
      credits
    });

    if (!topic.trim() || !niche || !tone) {
      toast.error('Please fill in all required fields');
      return;
    }

    if (credits <= 0) {
      toast.error('No credits remaining. Please upgrade your plan.');
      return;
    }

    setIsGenerating(true);
    console.log('Starting content generation...');

    try {
      const response = await fetch('/api/generate-content', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contentType,
          topic,
          niche,
          tone,
          additionalContext,
        }),
      });

      console.log('API response status:', response.status);

      if (!response.ok) {
        throw new Error('Failed to generate content');
      }

      const data = await response.json();
      console.log('Generated content received:', data);

      setGeneratedContent(data);
      setCredits(credits - 1);
      
      toast.success('🎉 Viral content generated!', {
        description: 'Your new hooks are ready to boost engagement!'
      });

    } catch (error) {
      console.error('Generation error:', error);
      toast.error('Failed to generate content. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const contentTypeConfig = {
    hooks: {
      icon: TrendingUp,
      title: 'Viral Hooks',
      description: 'Generate attention-grabbing opening lines'
    },
    'youtube-titles': {
      icon: Type,
      title: 'YouTube Titles',
      description: 'Create clickable video titles'
    },
    'tiktok-scripts': {
      icon: Video,
      title: 'TikTok Scripts',
      description: 'Full video script outlines'
    },
    hashtags: {
      icon: Hash,
      title: 'Smart Hashtags',
      description: 'Strategic hashtag combinations'
    }
  };

  return (
    <div className="space-y-8">
      <div className="grid lg:grid-cols-2 gap-8">
        <Card className="content-card">
          <CardHeader>
            <CardTitle className="gradient-text text-2xl flex items-center gap-2">
              <Wand2 className="w-6 h-6" />
              Content Generator
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <Tabs value={contentType} onValueChange={(value) => setContentType(value as ContentType)}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="hooks" className="text-xs">📈 Hooks</TabsTrigger>
                <TabsTrigger value="youtube-titles" className="text-xs">🎬 Titles</TabsTrigger>
              </TabsList>
              <TabsList className="grid w-full grid-cols-2 mt-2">
                <TabsTrigger value="tiktok-scripts" className="text-xs">🎭 Scripts</TabsTrigger>
                <TabsTrigger value="hashtags" className="text-xs">🏷️ Hashtags</TabsTrigger>
              </TabsList>
            </Tabs>

            <div className="space-y-4">
              <div>
                <Label htmlFor="topic" className="text-sm font-medium mb-2 block">
                  Topic or Content Idea *
                </Label>
                <Textarea
                  id="topic"
                  placeholder="e.g., Morning skincare routine for glowing skin"
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  className="min-h-[80px] bg-white/5 border-white/10"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="niche" className="text-sm font-medium mb-2 block">
                    Niche *
                  </Label>
                  <Select value={niche} onValueChange={setNiche}>
                    <SelectTrigger className="bg-white/5 border-white/10">
                      <SelectValue placeholder="Select niche" />
                    </SelectTrigger>
                    <SelectContent>
                      {niches.map((n) => (
                        <SelectItem key={n} value={n}>
                          {n}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="tone" className="text-sm font-medium mb-2 block">
                    Tone *
                  </Label>
                  <Select value={tone} onValueChange={setTone}>
                    <SelectTrigger className="bg-white/5 border-white/10">
                      <SelectValue placeholder="Select tone" />
                    </SelectTrigger>
                    <SelectContent>
                      {tones.map((t) => (
                        <SelectItem key={t} value={t}>
                          {t}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="context" className="text-sm font-medium mb-2 block">
                  Additional Context (Optional)
                </Label>
                <Input
                  id="context"
                  placeholder="Target audience, specific goals, etc."
                  value={additionalContext}
                  onChange={(e) => setAdditionalContext(e.target.value)}
                  className="bg-white/5 border-white/10"
                />
              </div>

              <Button
                onClick={handleGenerate}
                disabled={isGenerating || credits <= 0}
                className="w-full bg-gradient-to-r from-hook-purple to-hook-cyan hover:from-hook-purple/80 hover:to-hook-cyan/80 text-white font-semibold py-3 h-auto"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Generating Magic...
                  </>
                ) : (
                  <>
                    <Wand2 className="w-4 h-4 mr-2" />
                    Generate {contentTypeConfig[contentType].title} (1 Credit)
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-6">
          {generatedContent ? (
            <GeneratedContent content={generatedContent} contentType={contentType} />
          ) : (
            <Card className="content-card h-full flex items-center justify-center">
              <CardContent className="text-center p-8">
                <div className="w-16 h-16 rounded-full bg-gradient-mesh mx-auto mb-4 flex items-center justify-center">
                  {(() => {
                    const Icon = contentTypeConfig[contentType].icon;
                    return <Icon className="w-8 h-8 text-white" />;
                  })()}
                </div>
                <h3 className="text-xl font-semibold gradient-text mb-2">
                  {contentTypeConfig[contentType].title}
                </h3>
                <p className="text-muted-foreground">
                  {contentTypeConfig[contentType].description}
                </p>
                <div className="mt-4 text-sm text-muted-foreground">
                  Fill out the form and click generate to see your viral content here! ✨
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}