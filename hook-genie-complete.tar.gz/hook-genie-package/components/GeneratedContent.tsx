'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Copy, Heart, TrendingUp, Share, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';

interface GeneratedContentProps {
  content: {
    hooks?: string[];
    youtubeTitle?: string[];
    tiktokScript?: {
      hook: string;
      content: string[];
      cta: string;
    };
    hashtags?: {
      trending: string[];
      niche: string[];
      engagement: string[];
    };
    emojis?: string[];
    metrics?: {
      estimatedReach: string;
      engagementBoost: string;
      viralPotential: string;
    };
  };
  contentType: string;
}

export function GeneratedContent({ content, contentType }: GeneratedContentProps) {
  console.log('GeneratedContent rendered:', { content, contentType });

  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const copyToClipboard = async (text: string, index?: number) => {
    console.log('Copying to clipboard:', text.substring(0, 50) + '...');
    
    try {
      await navigator.clipboard.writeText(text);
      if (index !== undefined) {
        setCopiedIndex(index);
        setTimeout(() => setCopiedIndex(null), 2000);
      }
      toast.success('Copied to clipboard! 📋');
    } catch (error) {
      console.error('Failed to copy:', error);
      toast.error('Failed to copy to clipboard');
    }
  };

  const renderHooks = () => {
    if (!content.hooks) return null;

    return (
      <div className="space-y-4">
        {content.hooks.map((hook, index) => (
          <div key={index} className="p-4 rounded-lg bg-white/5 border border-white/10 group hover:bg-white/10 transition-all duration-300">
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1">
                <p className="text-sm font-medium text-white mb-2">Hook #{index + 1}</p>
                <p className="text-lg leading-relaxed">{hook}</p>
                <div className="flex items-center gap-2 mt-3">
                  <Badge variant="secondary" className="text-xs">
                    🔥 Viral Potential
                  </Badge>
                  <span className="text-xs text-muted-foreground">
                    Est. {Math.floor(Math.random() * 500 + 100)}K+ reach
                  </span>
                </div>
              </div>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => copyToClipboard(hook, index)}
                className="opacity-0 group-hover:opacity-100 transition-opacity"
              >
                {copiedIndex === index ? (
                  <CheckCircle className="w-4 h-4 text-green-400" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
              </Button>
            </div>
          </div>
        ))}
      </div>
    );
  };

  const renderYoutubeTitles = () => {
    if (!content.youtubeTitle) return null;

    return (
      <div className="space-y-4">
        {content.youtubeTitle.map((title, index) => (
          <div key={index} className="p-4 rounded-lg bg-white/5 border border-white/10 group hover:bg-white/10 transition-all duration-300">
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1">
                <p className="text-sm font-medium text-white mb-2">Title #{index + 1}</p>
                <p className="text-lg font-semibold leading-relaxed">{title}</p>
                <div className="flex items-center gap-2 mt-3">
                  <Badge variant="secondary" className="text-xs">
                    🎯 Click-worthy
                  </Badge>
                  <span className="text-xs text-muted-foreground">
                    CTR boost: +{Math.floor(Math.random() * 40 + 20)}%
                  </span>
                </div>
              </div>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => copyToClipboard(title, index)}
                className="opacity-0 group-hover:opacity-100 transition-opacity"
              >
                {copiedIndex === index ? (
                  <CheckCircle className="w-4 h-4 text-green-400" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
              </Button>
            </div>
          </div>
        ))}
      </div>
    );
  };

  const renderTikTokScript = () => {
    if (!content.tiktokScript) return null;

    const script = content.tiktokScript;
    const fullScript = `HOOK: ${script.hook}\n\nCONTENT:\n${script.content.join('\n')}\n\nCTA: ${script.cta}`;

    return (
      <div className="space-y-4">
        <div className="p-6 rounded-lg bg-white/5 border border-white/10">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-semibold gradient-text">TikTok Script</h4>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => copyToClipboard(fullScript)}
            >
              <Copy className="w-4 h-4 mr-2" />
              Copy Full Script
            </Button>
          </div>
          
          <div className="space-y-4">
            <div>
              <p className="text-sm font-medium text-hook-amber mb-2">🎣 HOOK</p>
              <p className="text-lg font-semibold">{script.hook}</p>
            </div>
            
            <div>
              <p className="text-sm font-medium text-hook-cyan mb-2">📝 CONTENT</p>
              <div className="space-y-2">
                {script.content.map((line, index) => (
                  <p key={index} className="text-sm pl-4 border-l-2 border-hook-purple/30">
                    {line}
                  </p>
                ))}
              </div>
            </div>
            
            <div>
              <p className="text-sm font-medium text-hook-purple mb-2">🎯 CALL TO ACTION</p>
              <p className="text-lg font-semibold">{script.cta}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2 mt-4">
            <Badge variant="secondary" className="text-xs">
              🎬 Video-ready
            </Badge>
            <span className="text-xs text-muted-foreground">
              Estimated length: {Math.floor(Math.random() * 30 + 15)}s
            </span>
          </div>
        </div>
      </div>
    );
  };

  const renderHashtags = () => {
    if (!content.hashtags) return null;

    const allHashtags = [
      ...content.hashtags.trending,
      ...content.hashtags.niche,
      ...content.hashtags.engagement
    ].join(' ');

    return (
      <div className="space-y-4">
        <div className="p-6 rounded-lg bg-white/5 border border-white/10">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-semibold gradient-text">Strategic Hashtags</h4>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => copyToClipboard(allHashtags)}
            >
              <Copy className="w-4 h-4 mr-2" />
              Copy All
            </Button>
          </div>
          
          <div className="space-y-4">
            <div>
              <p className="text-sm font-medium text-red-400 mb-2">🔥 Trending</p>
              <div className="flex flex-wrap gap-2">
                {content.hashtags.trending.map((tag, index) => (
                  <Badge key={index} variant="outline" className="text-xs border-red-400/30 text-red-400">
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>
            
            <div>
              <p className="text-sm font-medium text-hook-cyan mb-2">🎯 Niche-Specific</p>
              <div className="flex flex-wrap gap-2">
                {content.hashtags.niche.map((tag, index) => (
                  <Badge key={index} variant="outline" className="text-xs border-hook-cyan/30 text-hook-cyan">
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>
            
            <div>
              <p className="text-sm font-medium text-hook-purple mb-2">💫 Engagement Boosters</p>
              <div className="flex flex-wrap gap-2">
                {content.hashtags.engagement.map((tag, index) => (
                  <Badge key={index} variant="outline" className="text-xs border-hook-purple/30 text-hook-purple">
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderMetrics = () => {
    if (!content.metrics) return null;

    return (
      <div className="grid grid-cols-3 gap-4 mt-6">
        <div className="text-center p-4 rounded-lg bg-gradient-to-br from-hook-purple/10 to-hook-purple/5 border border-hook-purple/20">
          <TrendingUp className="w-6 h-6 text-hook-purple mx-auto mb-2" />
          <p className="text-sm font-medium">Estimated Reach</p>
          <p className="text-lg font-bold gradient-text">{content.metrics.estimatedReach}</p>
        </div>
        <div className="text-center p-4 rounded-lg bg-gradient-to-br from-hook-cyan/10 to-hook-cyan/5 border border-hook-cyan/20">
          <Heart className="w-6 h-6 text-hook-cyan mx-auto mb-2" />
          <p className="text-sm font-medium">Engagement Boost</p>
          <p className="text-lg font-bold text-hook-cyan">{content.metrics.engagementBoost}</p>
        </div>
        <div className="text-center p-4 rounded-lg bg-gradient-to-br from-hook-amber/10 to-hook-amber/5 border border-hook-amber/20">
          <Share className="w-6 h-6 text-hook-amber mx-auto mb-2" />
          <p className="text-sm font-medium">Viral Potential</p>
          <p className="text-lg font-bold text-hook-amber">{content.metrics.viralPotential}</p>
        </div>
      </div>
    );
  };

  return (
    <Card className="content-card animate-fade-in-up">
      <CardHeader>
        <CardTitle className="gradient-text flex items-center gap-2">
          ✨ Generated Content
          <Badge className="bg-gradient-to-r from-hook-purple to-hook-cyan text-white">
            Demo Mode
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {contentType === 'hooks' && renderHooks()}
        {contentType === 'youtube-titles' && renderYoutubeTitles()}
        {contentType === 'tiktok-scripts' && renderTikTokScript()}
        {contentType === 'hashtags' && renderHashtags()}
        
        {content.emojis && content.emojis.length > 0 && (
          <div className="mt-6 p-4 rounded-lg bg-white/5 border border-white/10">
            <p className="text-sm font-medium mb-2">🎨 Suggested Emojis</p>
            <div className="flex flex-wrap gap-2">
              {content.emojis.map((emoji, index) => (
                <span key={index} className="text-2xl cursor-pointer hover:scale-110 transition-transform">
                  {emoji}
                </span>
              ))}
            </div>
          </div>
        )}
        
        {renderMetrics()}
      </CardContent>
    </Card>
  );
}