'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Check, Zap, Crown, Rocket, Star } from 'lucide-react';
import { toast } from 'sonner';

const plans = {
  monthly: {
    starter: {
      name: 'Starter',
      price: 9,
      credits: 100,
      icon: Zap,
      popular: false,
      features: [
        '100 AI generations/month',
        'Viral hooks & captions',
        'Basic hashtag suggestions',
        'TikTok script outlines',
        'YouTube title ideas',
        'Email support'
      ]
    },
    creator: {
      name: 'Creator Pro',
      price: 29,
      credits: 500,
      icon: Crown,
      popular: true,
      features: [
        '500 AI generations/month',
        'All content types',
        'Advanced hashtag research',
        'Content calendar integration',
        'Performance analytics',
        'Voice narration (coming soon)',
        'Priority support',
        'Custom tone training'
      ]
    },
    agency: {
      name: 'Agency',
      price: 79,
      credits: 2000,
      icon: Rocket,
      popular: false,
      features: [
        '2000 AI generations/month',
        'Multi-client management',
        'White-label options',
        'Team collaboration',
        'API access',
        'Custom integrations',
        'Dedicated account manager',
        'Advanced analytics'
      ]
    }
  },
  yearly: {
    starter: {
      name: 'Starter',
      price: 7,
      originalPrice: 9,
      credits: 100,
      icon: Zap,
      popular: false,
      features: [
        '100 AI generations/month',
        'Viral hooks & captions',
        'Basic hashtag suggestions',
        'TikTok script outlines',
        'YouTube title ideas',
        'Email support'
      ]
    },
    creator: {
      name: 'Creator Pro',
      price: 19,
      originalPrice: 29,
      credits: 500,
      icon: Crown,
      popular: true,
      features: [
        '500 AI generations/month',
        'All content types',
        'Advanced hashtag research',
        'Content calendar integration',
        'Performance analytics',
        'Voice narration (coming soon)',
        'Priority support',
        'Custom tone training'
      ]
    },
    agency: {
      name: 'Agency',
      price: 59,
      originalPrice: 79,
      credits: 2000,
      icon: Rocket,
      popular: false,
      features: [
        '2000 AI generations/month',
        'Multi-client management',
        'White-label options',
        'Team collaboration',
        'API access',
        'Custom integrations',
        'Dedicated account manager',
        'Advanced analytics'
      ]
    }
  }
};

export function PricingCard() {
  console.log('PricingCard component rendered');
  
  const [isYearly, setIsYearly] = useState(false);
  const currentPlans = isYearly ? plans.yearly : plans.monthly;

  const handleSubscribe = async (planName: string, price: number, credits: number) => {
    console.log('Subscribe clicked for plan:', planName, 'price:', price, 'credits:', credits);
    
    try {
      toast.success(`🚀 Redirecting to checkout for ${planName} plan...`, {
        description: 'You\'ll be redirected to our secure payment processor.'
      });

      const response = await fetch('/api/checkout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          planName,
          price,
          credits,
          isYearly
        }),
      });

      const data = await response.json();
      console.log('Checkout response:', data);

      if (data.demoMode) {
        console.log('Demo mode detected, redirecting to demo success page');
        toast.info('✨ Demo Mode: Exploring Hook Genie features', {
          description: 'Add Stripe API keys for real payments.'
        });
        window.location.href = data.checkoutUrl;
        return;
      }

      if (data.checkoutUrl) {
        console.log('Redirecting to Stripe checkout:', data.checkoutUrl);
        window.location.href = data.checkoutUrl;
      } else {
        throw new Error(data.error || 'Failed to create checkout session');
      }
    } catch (error) {
      console.error('Checkout error:', error);
      toast.error('❌ Checkout failed', {
        description: 'Please try again or contact support if the issue persists.'
      });
    }
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold gradient-text mb-4">
          Choose Your Creative Power 🚀
        </h2>
        <p className="text-xl text-muted-foreground mb-8">
          Unlock viral content generation with our flexible pricing plans
        </p>
        
        <div className="flex items-center justify-center gap-4 mb-8">
          <span className={`text-sm font-medium ${!isYearly ? 'text-white' : 'text-muted-foreground'}`}>
            Monthly
          </span>
          <Switch
            checked={isYearly}
            onCheckedChange={setIsYearly}
            className="data-[state=checked]:bg-hook-purple"
          />
          <span className={`text-sm font-medium ${isYearly ? 'text-white' : 'text-muted-foreground'}`}>
            Yearly
          </span>
          <Badge className="bg-gradient-to-r from-hook-purple to-hook-amber text-white ml-2">
            Save 30%
          </Badge>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {Object.entries(currentPlans).map(([key, plan]) => {
          const Icon = plan.icon;
          const isPopular = plan.popular;
          const hasOriginalPrice = 'originalPrice' in plan;
          const originalPrice = hasOriginalPrice ? (plan as any).originalPrice : null;
          
          return (
            <Card 
              key={key}
              className={`relative content-card ${isPopular ? 'premium-glow' : ''} ${
                isPopular ? 'ring-2 ring-hook-purple/50' : ''
              }`}
            >
              {isPopular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-gradient-to-r from-hook-purple to-hook-amber text-white px-4 py-1">
                    <Star className="w-3 h-3 mr-1" />
                    Most Popular
                  </Badge>
                </div>
              )}
              
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 rounded-full bg-gradient-mesh mx-auto mb-4 flex items-center justify-center">
                  <Icon className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-2xl font-bold gradient-text">{plan.name}</CardTitle>
                <div className="mt-4">
                  <div className="flex items-center justify-center gap-2">
                    <span className="text-4xl font-bold">${plan.price}</span>
                    <div className="text-left">
                      {isYearly && originalPrice && (
                        <div className="text-sm text-muted-foreground line-through">
                          ${originalPrice}
                        </div>
                      )}
                      <div className="text-sm text-muted-foreground">/month</div>
                    </div>
                  </div>
                  {isYearly && originalPrice && (
                    <p className="text-sm text-hook-amber mt-2">
                      Billed annually • Save ${(originalPrice - plan.price) * 12}/year
                    </p>
                  )}
                </div>
              </CardHeader>
              
              <CardContent className="space-y-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-hook-cyan mb-2">
                    {plan.credits.toLocaleString()} Credits
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Generate {plan.credits} pieces of viral content
                  </p>
                </div>
                
                <ul className="space-y-3">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-hook-cyan mt-0.5 flex-shrink-0" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <Button
                  onClick={() => handleSubscribe(plan.name, plan.price, plan.credits)}
                  className={`w-full h-12 font-semibold ${
                    isPopular
                      ? 'bg-gradient-to-r from-hook-purple to-hook-cyan hover:from-hook-purple/80 hover:to-hook-cyan/80'
                      : 'bg-white/10 hover:bg-white/20 border border-white/20'
                  }`}
                >
                  {isPopular ? '🚀 Start Creating' : 'Choose Plan'}
                </Button>
                
                <p className="text-xs text-center text-muted-foreground">
                  Cancel anytime • 7-day money-back guarantee
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>
      
      <div className="grid md:grid-cols-3 gap-6 mt-12">
        <div className="text-center p-6 rounded-xl glass-morphism border border-white/10">
          <div className="w-12 h-12 rounded-lg bg-hook-purple/20 mx-auto mb-4 flex items-center justify-center">
            <Zap className="w-6 h-6 text-hook-purple" />
          </div>
          <h3 className="font-semibold mb-2">Instant Generation</h3>
          <p className="text-sm text-muted-foreground">
            Get viral content in seconds, not hours
          </p>
        </div>
        
        <div className="text-center p-6 rounded-xl glass-morphism border border-white/10">
          <div className="w-12 h-12 rounded-lg bg-hook-cyan/20 mx-auto mb-4 flex items-center justify-center">
            <Crown className="w-6 h-6 text-hook-cyan" />
          </div>
          <h3 className="font-semibold mb-2">Proven Results</h3>
          <p className="text-sm text-muted-foreground">
            Backed by 10M+ viral views generated
          </p>
        </div>
        
        <div className="text-center p-6 rounded-xl glass-morphism border border-white/10">
          <div className="w-12 h-12 rounded-lg bg-hook-amber/20 mx-auto mb-4 flex items-center justify-center">
            <Rocket className="w-6 h-6 text-hook-amber" />
          </div>
          <h3 className="font-semibold mb-2">Scale Your Growth</h3>
          <p className="text-sm text-muted-foreground">
            From solo creator to viral influencer
          </p>
        </div>
      </div>
    </div>
  );
}