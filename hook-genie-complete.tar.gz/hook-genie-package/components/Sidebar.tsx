'use client';

import { NavigationSection } from '@/app/page';
import { cn } from '@/lib/utils';
import { 
  Wand2, 
  CreditCard, 
  Calendar, 
  History, 
  Sparkles,
  TrendingUp,
  Video,
  Hash,
  X
} from 'lucide-react';

interface SidebarProps {
  activeSection: NavigationSection;
  setActiveSection: (section: NavigationSection) => void;
  isOpen: boolean;
  onClose: () => void;
}

const navigationItems = [
  {
    id: 'generator' as NavigationSection,
    label: 'Content Generator',
    icon: Wand2,
    description: 'Generate viral hooks & captions'
  },
  {
    id: 'calendar' as NavigationSection,
    label: 'Content Calendar',
    icon: Calendar,
    description: 'Plan your content strategy'
  },
  {
    id: 'pricing' as NavigationSection,
    label: 'Pricing',
    icon: CreditCard,
    description: 'Upgrade your plan'
  },
  {
    id: 'history' as NavigationSection,
    label: 'History',
    icon: History,
    description: 'Your generated content'
  }
];

const features = [
  { icon: Sparkles, text: 'Viral Hooks' },
  { icon: Hash, text: 'Smart Hashtags' },
  { icon: Video, text: 'TikTok Scripts' },
  { icon: TrendingUp, text: 'YouTube Titles' }
];

export function Sidebar({ activeSection, setActiveSection, isOpen, onClose }: SidebarProps) {
  console.log('Sidebar rendered, activeSection:', activeSection, 'isOpen:', isOpen);

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 lg:hidden" 
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <div className={cn(
        "fixed lg:static inset-y-0 left-0 z-50 w-80 glass-morphism border-r border-white/10 p-6 flex flex-col transition-transform duration-300 lg:translate-x-0",
        isOpen ? "translate-x-0" : "-translate-x-full"
      )}>
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-gradient-mesh flex items-center justify-center">
            <Wand2 className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <h2 className="text-xl font-bold gradient-text">Hook Genie</h2>
            <p className="text-sm text-muted-foreground">AI Content Studio</p>
          </div>
          {/* Mobile Close Button */}
          <button
            onClick={onClose}
            className="lg:hidden p-2 rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="grid grid-cols-2 gap-3 mb-6">
          {features.map((feature, index) => (
            <div key={index} className="flex items-center gap-2 p-3 rounded-lg bg-white/5 border border-white/10">
              <feature.icon className="w-4 h-4 text-hook-cyan" />
              <span className="text-xs font-medium">{feature.text}</span>
            </div>
          ))}
        </div>
      </div>

      <nav className="flex-1">
        <ul className="space-y-2">
          {navigationItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeSection === item.id;
            
            return (
              <li key={item.id}>
                <button
                  onClick={() => {
                    console.log('Navigation clicked:', item.id);
                    setActiveSection(item.id);
                    onClose(); // Close mobile sidebar when navigation item is clicked
                  }}
                  className={cn(
                    'w-full text-left p-4 rounded-xl transition-all duration-300 group',
                    isActive 
                      ? 'bg-gradient-to-r from-hook-purple/20 to-hook-cyan/20 border border-hook-purple/30 glow-box' 
                      : 'hover:bg-white/5 border border-transparent hover:border-white/10'
                  )}
                >
                  <div className="flex items-center gap-3 mb-1">
                    <Icon className={cn(
                      'w-5 h-5 transition-colors',
                      isActive ? 'text-hook-purple' : 'text-muted-foreground group-hover:text-hook-cyan'
                    )} />
                    <span className={cn(
                      'font-medium transition-colors',
                      isActive ? 'text-white' : 'text-muted-foreground group-hover:text-white'
                    )}>
                      {item.label}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground ml-8">
                    {item.description}
                  </p>
                </button>
              </li>
            );
          })}
        </ul>
      </nav>

      <div className="mt-auto p-4 rounded-xl bg-gradient-to-r from-hook-purple/10 to-hook-amber/10 border border-hook-purple/20">
        <div className="text-center">
          <Sparkles className="w-8 h-8 text-hook-amber mx-auto mb-2" />
          <p className="text-sm font-medium mb-1">Boost Your Reach</p>
          <p className="text-xs text-muted-foreground mb-3">
            Generate viral content that actually converts
          </p>
          <div className="flex items-center justify-center gap-1 text-xs text-hook-amber">
            <span>🔥</span>
            <span>10M+ views generated</span>
          </div>
        </div>
      </div>
    </div>
    </>
  );
}