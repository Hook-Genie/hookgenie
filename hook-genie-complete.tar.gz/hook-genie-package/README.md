# 🪝 Hook Genie - Viral Social Media Content Generator

A powerful AI-driven tool for creating viral social media hooks, captions, and hashtags.

## ✨ Features

- **AI Content Generation**: Viral hooks, captions, and hashtags
- **Multi-Platform Support**: TikTok, Instagram, YouTube, Twitter
- **Content Calendar**: Plan and organize your posts
- **Credit System**: Monetized with Stripe integration
- **Responsive Design**: Works on all devices
- **Demo Mode**: Try before you buy

## 🚀 Quick Setup

### 1. Install Dependencies
```bash
npm install
```

### 2. Environment Variables
Create `.env.local` file in the root directory:

```bash
# Stripe Configuration (Required for monetization)
STRIPE_SECRET_KEY=sk_test_your_stripe_secret_key
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_your_stripe_publishable_key

# OpenAI Configuration (Optional - falls back to demo mode)
OPENAI_API_KEY=sk-your_openai_api_key
```

### 3. Stripe Setup
1. Create account at [stripe.com](https://stripe.com)
2. Get your API keys from Dashboard → Developers → API keys
3. Create a product for "Hook Genie Pro" ($9.99/month)
4. Add the price ID to `components/PricingCard.tsx`

### 4. Run Development Server
```bash
npm run dev
```

Visit http://localhost:3000 to see your app!

## 🌐 Deployment Options

### Vercel (Recommended - Free)
1. Push code to GitHub
2. Connect to [vercel.com](https://vercel.com)
3. Add environment variables in Vercel dashboard
4. Deploy automatically

### Netlify (Alternative - Free)
1. Push code to GitHub
2. Connect to [netlify.com](https://netlify.com)
3. Add environment variables in Netlify dashboard
4. Deploy automatically

### Manual Deployment
1. Build: `npm run build`
2. Upload `out/` folder to any hosting service

## 💰 Monetization

- **Stripe Integration**: Collect payments automatically
- **Credit System**: Users buy credits or subscriptions
- **Dashboard**: Track earnings in Stripe dashboard
- **Payouts**: Automatic bank transfers via Stripe

## 🛠 Tech Stack

- **Next.js 14**: React framework
- **TypeScript**: Type safety
- **Tailwind CSS**: Styling
- **Shadcn/ui**: UI components
- **Stripe**: Payment processing
- **Vercel AI SDK**: AI integration

## 📞 Support

Created with ❤️ using Macaly.com