# 🚀 Hook Genie Deployment Guide

## Option 1: Vercel (Recommended - Free)

### Why Vercel?
- ✅ **Free tier** for personal projects
- ✅ **Automatic deployments** from GitHub
- ✅ **Built for Next.js** (same company)
- ✅ **Global CDN** for fast loading
- ✅ **Easy environment variables**

### Steps:
1. **Upload to GitHub**
   - Create new repository on [github.com](https://github.com)
   - Upload your Hook Genie files
   - Don't include `.env.local`!

2. **Deploy to Vercel**
   - Visit [vercel.com](https://vercel.com)
   - Sign up/login with GitHub
   - Click "New Project"
   - Import your Hook Genie repository
   - Vercel auto-detects Next.js settings

3. **Add Environment Variables**
   - In Vercel dashboard → Settings → Environment Variables
   - Add your Stripe keys:
     ```
     STRIPE_SECRET_KEY=sk_test_your_key
     NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_your_key
     OPENAI_API_KEY=sk-your_openai_key (optional)
     ```

4. **Deploy**
   - Click "Deploy"
   - Get your live URL (e.g., hook-genie.vercel.app)
   - Every GitHub push auto-deploys!

---

## Option 2: Netlify (Alternative - Free)

### Steps:
1. **Upload to GitHub** (same as above)
2. **Deploy to Netlify**
   - Visit [netlify.com](https://netlify.com)
   - "New site from Git"
   - Connect GitHub repository
   - Build command: `npm run build`
   - Publish directory: `out`

3. **Add Environment Variables**
   - Site settings → Environment variables
   - Add same Stripe/OpenAI keys

---

## Option 3: Traditional Hosting

### For cPanel/shared hosting:
1. **Build Static Version**
   ```bash
   npm run build
   ```
2. **Upload** the generated files
3. **Configure** environment variables through hosting panel

---

## 💳 Stripe Configuration

### Get Your Keys:
1. **Stripe Dashboard** → Developers → API keys
2. **Copy** both test keys initially
3. **Switch to live keys** when ready for real payments

### Create Product:
1. **Stripe Dashboard** → Products
2. **Create** "Hook Genie Pro"
3. **Price**: $9.99/month (or your choice)
4. **Copy price ID** to update in code

### Webhooks (Advanced):
For production, set up webhooks for subscription management.

---

## 🎯 Going Live Checklist

- [ ] Code uploaded to GitHub
- [ ] Deployed to Vercel/Netlify
- [ ] Stripe keys added to environment
- [ ] Test payment flow works
- [ ] Switch to Stripe live mode
- [ ] Custom domain connected (optional)
- [ ] Analytics added (optional)

**Your Hook Genie is ready to make money! 💰**